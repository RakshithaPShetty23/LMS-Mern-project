PORT = 3000
MONGO_URI = mongodb+srv://rakshithapshetty23:1Z4PYubrOQyCFHT3@cluster0.xhhofwt.mongodb.net/mat_app?retryWrites=true&w=majority
JWT_SECRET = zino123
JWT_EXPIRY = 7d

CLOUDINARY_CLOUD_NAME = ddonospw4
CLOUDINARY_API_KEY = 276589431542937
CLOUDINARY_API_SECRET = hpoYge0-85eHjDH3Nvv70Nu4MTE

SMTP_HOST = smtp.gmail.com
SMTP_PORT = 587
SMTP_USERNAME = rakshithapshetty23@gmail.com
SMTP_PASSWORD = Rakshu@123
SMTP_FROM_EMAIL = rakshithapshetty23@gmail.com



FRONTEND_URL = http://localhost:3000

CONTACT_US_EMAIL = rakshithapshetty23@gmail.com